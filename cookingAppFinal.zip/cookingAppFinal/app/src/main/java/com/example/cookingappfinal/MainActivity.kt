package com.example.cookingappfinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.view.View
import android.widget.*
import java.lang.Math.round
import java.math.RoundingMode
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }



    fun calculate(view: View) {

        // --------------------------- 1. FOR VOLUME ---------------------------
        //get the user input
        val volumeInput = findViewById<EditText>(R.id.volInput)
        //turn to string
        val volInput = volumeInput.text.toString()
        //turn to int
        val num: Float? = volInput.toFloatOrNull()
        //get what you're changing
        val output1 = findViewById<TextView>(R.id.output1)
        val output2 = findViewById<TextView>(R.id.output2)
        val output3 = findViewById<TextView>(R.id.output3)
        //get before unit
        val leftValSpinner = findViewById<Spinner>(R.id.leftVolSpinner)
        val leftSpinnerLocation = leftValSpinner.selectedItem
        //get after unit
        val rightValSpinner = findViewById<Spinner>(R.id.rightVolSpinner)
        val rightSpinnerLocation = rightValSpinner.selectedItem


           //if left is tbsp, convert to each right option
           if ("$leftSpinnerLocation" == "tbsp") {
               if(num == null){
                   output1.text = "0"
               }
               else if ("$rightSpinnerLocation" == "tbsp") {
                   output1.text = "$num" //tbsp -> tbsp
               } else if ("$rightSpinnerLocation" == "tsp") {
                   val tbspToTsp = (num * 3) //tbsp -> tsp
                   output1.text = "$tbspToTsp"
               } else if ("$rightSpinnerLocation" == "cups") {
                   val tbspToCups = (num / 16)
                   output1.text = "$tbspToCups" //tbsp -> c
               }
           }
           //if left is tsp, convert to each right option
           else if ("$leftSpinnerLocation" == "tsp") {
               if(num == null){
                   output1.text = "0"
               }
               else if ("$rightSpinnerLocation" == "tbsp") {
                   val tspToTbsp = (num / 3)
                   output1.text = "$tspToTbsp" //tsp -> tbsp
               } else if ("$rightSpinnerLocation" == "tsp") {
                   output1.text = "$num" //tsp -> tsp
               } else if ("$rightSpinnerLocation" == "cups") {
                   val tspToC = (num / 48)
                   output1.text = "$tspToC" //tsp -> c
               }
           }
           //if left is cups, convert to each right option
           else if ("$leftSpinnerLocation" == "cups") {
               if(num == null){
                   output1.text = "0"
               }
               else if ("$rightSpinnerLocation" == "tbsp") {
                   val cToTbsp = num * 16
                   output1.text = "$cToTbsp" //c -> tbsp
               } else if ("$rightSpinnerLocation" == "tsp") {
                   val cToTsp = num * 48
                   output1.text = "$cToTsp" //c -> tsp
               } else if ("$rightSpinnerLocation" == "cups") {
                   output1.text = "$num" //c -> c
               }
           }


           // --------------------------- 2. FOR TEMPERATURE ---------------------------
           //get the user input
           val tempInput = findViewById<EditText>(R.id.tempInput)
           //turn to string
           val tInput = tempInput.text.toString()
           //turn to int
           val num1: Float? = tInput.toFloatOrNull()
           //get what you're changing

           //get before unit
           val leftTempSpinner = findViewById<Spinner>(R.id.leftTempSpinner)
           val leftTempLocation = leftTempSpinner.selectedItem
           //get after unit
           val rightTempSpinner = findViewById<Spinner>(R.id.rightTempSpinner)
           val rightTempLocation = rightTempSpinner.selectedItem
           //if left is F, convert to C
           if ("$leftTempLocation" == "°F") {
               if(num1 == null){
                   output2.text = "0"
               }
               else if ("$rightTempLocation" == "°F") {
                   output2.text = "$num1" //F -> F
               }
               else if ("$rightTempLocation" == "°C") {
                   val fToC = ((num1 - 32) * 5) / 9
                   output2.text = "$fToC" //F -> C
               }
           }
           //if left is C, convert to F
           else if ("$leftTempLocation" == "°C") {
               if(num1 == null){
                   output2.text = "0"
               }
               else if ("$rightTempLocation" == "°C") {
                   output2.text = "$num1" //C -> C
               } else if ("$rightTempLocation" == "°F") {
                   val cToF = ((9 * num1) / 5 + 32)
                   output2.text = "$cToF" //C -> F
               }
           }

           // 3. --------------------------- FOR MASS ---------------------------

           //get the user input
           val massInput = findViewById<EditText>(R.id.massInput)
           //turn to string
           val mInput = massInput.text.toString()
           //turn to int
           val num2: Float? = mInput.toFloatOrNull()
           //get what you're changing

           //get before unit
           val leftMassSpinner = findViewById<Spinner>(R.id.leftMassSpinner)
           val leftMassLocation = leftMassSpinner.selectedItem
           //get after unit
           val rightMassSpinner = findViewById<Spinner>(R.id.rightMassSpinner)
           val rightMassLocation = rightMassSpinner.selectedItem
           //if left is g, convert to oz
           if ("$leftMassLocation" == "g") {
               if(num2 == null){
                   output3.text = "0"
               }
               else if ("$rightMassLocation" == "g") {
                   output3.text = "$num2" //F -> F
               } else if ("$rightMassLocation" == "oz") {
                   var gToOz = num2 / 28.35
                   output3.text = "$gToOz" //F -> C
               }
           }
           //if left is oz, convert to g
           else if ("$leftMassLocation" == "oz") {
               if(num2 == null){
                   output3.text = "0"
               }
               else if ("$rightMassLocation" == "g") {
                   var ozToG = num2 * 28.35
                   output3.text = "$ozToG" //C -> C
               } else if ("$rightMassLocation" == "oz") {
                   output3.text = "$num2" //C -> F
               }
           }


       }
fun reset(view: View){
    val volumeInput = findViewById<EditText>(R.id.volInput)
    val tempInput = findViewById<EditText>(R.id.tempInput)
    val massInput = findViewById<EditText>(R.id.massInput)

    val output1 = findViewById<TextView>(R.id.output1)
    val output2 = findViewById<TextView>(R.id.output2)
    val output3 = findViewById<TextView>(R.id.output3)

    volumeInput.setText("");
    tempInput.setText("");
    massInput.setText("");

    output1.text = "0"
    output2.text = "0"
    output3.text = "0"
}

    }
