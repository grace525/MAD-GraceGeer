package com.example.lab8gracegeer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

const val USER_MESSAGE = "com.example.lab8GraceGeer.MESSAGE"

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    // declaring variables
    lateinit var spinner: Spinner
    private lateinit var selectedText: TextView
    lateinit var btnSubmit: Button
   // private val spinnerItem: Array<String> = arrayOf(R.values.strings)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // wiring up widget
        selectedText = findViewById(R.id.selectedText)
        btnSubmit = findViewById(R.id.btnSubmit)
        spinner = findViewById(R.id.spinner)
        spinner.onItemSelectedListener = this

        btnSubmit.setOnClickListener {
            grabUserInput()
//            val intent = Intent(this, SecondActivity::class.java)
//            startActivity(intent)
        }

        ArrayAdapter.createFromResource(this, R.array.chooseHere, android.R.layout.simple_spinner_item)
            .also { adapter ->
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
            }
    }

    // needed for the spinner & adapter
    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id:Long) {

        selectedText.text = resources.getStringArray(R.array.chooseHere)[position]
    }


    // needed for the spinner & adapter
    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("not yet implemented")
    }


    private fun grabUserInput() {
        val message: String = selectedText.text.toString()
        // creating the intent
        val intent = Intent(this, SecondActivity::class.java)
        // ... first value of intent putExtra is the key (the constant that
        // was created at the top of this file)
        // ... second value is going to be message from the spinner (once it's wired up)
        intent.putExtra(USER_MESSAGE, message)

        startActivity(intent)
    }
}