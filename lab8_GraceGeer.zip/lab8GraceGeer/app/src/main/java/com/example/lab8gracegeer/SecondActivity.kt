package com.example.lab8gracegeer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class SecondActivity : AppCompatActivity() {

    // Declaring the variables
    lateinit var tvUserReply: TextView
    private lateinit var btnBack: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        val message: String? = intent.getStringExtra(USER_MESSAGE)

        // wire up widget
        tvUserReply = findViewById(R.id.tvUserReply)
        btnBack = findViewById(R.id.btnBack)


        btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // load message to text view
        tvUserReply.text = message
    }
}